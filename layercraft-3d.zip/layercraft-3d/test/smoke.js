// Builds sample .3mf files in test/fixtures and checks the volume/size math.
// Run: npm test
import JSZip from 'jszip';
import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import { analyze3MF, priceCustomItem } from '../public/js/pricing.js';

const dir = path.join(path.dirname(fileURLToPath(import.meta.url)), 'fixtures');
await fs.mkdir(dir, { recursive: true });
const config = JSON.parse(await fs.readFile(new URL('../config.json', import.meta.url), 'utf8'));

// Axis-aligned box mesh (outward-facing triangles), size in model units.
function boxMesh(sx, sy, sz) {
  const v = [[0,0,0],[sx,0,0],[sx,sy,0],[0,sy,0],[0,0,sz],[sx,0,sz],[sx,sy,sz],[0,sy,sz]];
  const t = [[0,2,1],[0,3,2],[4,5,6],[4,6,7],[0,1,5],[0,5,4],[1,2,6],[1,6,5],[2,3,7],[2,7,6],[3,0,4],[3,4,7]];
  return `<mesh><vertices>${v.map(([x,y,z]) => `<vertex x="${x}" y="${y}" z="${z}"/>`).join('')}</vertices>` +
    `<triangles>${t.map(([a,b,c]) => `<triangle v1="${a}" v2="${b}" v3="${c}"/>`).join('')}</triangles></mesh>`;
}

const CT = '<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="model" ContentType="application/vnd.ms-package.3dmanufacturing-3dmodel+xml"/></Types>';
const RELS = '<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Target="/3D/3dmodel.model" Id="rel0" Type="http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel"/></Relationships>';

async function write3mf(name, files) {
  const zip = new JSZip();
  zip.file('[Content_Types].xml', CT);
  zip.file('_rels/.rels', RELS);
  for (const [p, content] of Object.entries(files)) zip.file(p, content);
  const buf = await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' });
  await fs.writeFile(path.join(dir, name), buf);
  return buf;
}

const near = (a, b, tol = 1e-6) => assert.ok(Math.abs(a - b) <= tol * Math.max(1, Math.abs(b)), `${a} ≈ ${b}`);

// 1) Simple 20 mm cube -> 8 cm³
{
  const buf = await write3mf('cube-20mm.3mf', {
    '3D/3dmodel.model': `<?xml version="1.0"?><model unit="millimeter" xmlns="http://schemas.microsoft.com/3dmanufacturing/core/2015/02"><resources><object id="1" type="model">${boxMesh(20,20,20)}</object></resources><build><item objectid="1"/></build></model>`,
  });
  const a = await analyze3MF(buf, JSZip);
  near(a.volumeCm3, 8);
  a.sizeMm.forEach((s) => near(s, 20));
  const p = priceCustomItem(a, { material: 'pla', strength: 'standard', qty: 2 }, config);
  // shell = 24 cm² × 0.1 cm = 2.4 cm³; + 20% of the other 5.6 cm³ = 3.52 cm³ × 1.24 = 4.36 g
  near(a.areaCm2, 24);
  near(p.grams, 4.4, 0.02);
  assert.equal(p.each, 3); // below minimum
  console.log('✔ cube-20mm.3mf', a, `→ ${p.grams} g, ${p.each}/ea`);
}

// 2) Bambu-style: build item -> component in a separate model file, with 2x scale,
//    a 90° rotation, and two build instances. Box 10×20×30 mm => 6 cm³ × 8 (scale) × 2 = 96 cm³
{
  const rot90z = '0 1 0 -1 0 0 0 0 1'; // rotate 90° about Z
  const buf = await write3mf('bambu-style-components.3mf', {
    '3D/3dmodel.model': `<?xml version="1.0"?><model unit="millimeter" xmlns="http://schemas.microsoft.com/3dmanufacturing/core/2015/02" xmlns:p="http://schemas.microsoft.com/3dmanufacturing/production/2015/06"><resources>
      <object id="2" type="model"><components><component p:path="/3D/Objects/object_1.model" objectid="1" transform="2 0 0 0 2 0 0 0 2 0 0 0"/></components></object>
      </resources><build>
      <item objectid="2" transform="${rot90z} 100 100 0" printable="1"/>
      <item objectid="2" transform="1 0 0 0 1 0 0 0 1 200 0 0" printable="1"/>
      <item objectid="2" transform="1 0 0 0 1 0 0 0 1 0 0 0" printable="0"/>
      </build></model>`,
    '3D/Objects/object_1.model': `<?xml version="1.0"?><model unit="millimeter" xmlns="http://schemas.microsoft.com/3dmanufacturing/core/2015/02"><resources><object id="1" type="model">${boxMesh(10,20,30)}</object></resources></model>`,
    'Metadata/slice_info.config': '<config><plate><filament id="1" type="PLA" used_m="10" used_g="31.25"/></plate></config>',
  });
  const a = await analyze3MF(buf, JSZip);
  near(a.volumeCm3, 96);
  assert.equal(a.parts, 2);
  assert.equal(a.slicedGrams, 31.3);
  // Each instance is a 2x-scaled 10×20×30 box; the first is rotated 90°, so 40×20×60.
  // Size is per object, not the spread across the plate.
  assert.deepEqual(a.sizeMm.map(Math.round), [40, 20, 60]);
  assert.deepEqual(a.itemSizesMm.map((s) => s.map(Math.round)), [[40, 20, 60], [20, 40, 60]]);
  near(a.areaCm2, 2 * 4 * 22); // 22 cm² box surface × 2² scale × 2 instances
  console.log('✔ bambu-style-components.3mf', a);
}

// 3) Inch units: 1 inch cube = 16.387 cm³
{
  const buf = await write3mf('cube-1inch.3mf', {
    '3D/3dmodel.model': `<?xml version="1.0"?><model unit="inch" xmlns="http://schemas.microsoft.com/3dmanufacturing/core/2015/02"><resources><object id="1">${boxMesh(1,1,1)}</object></resources><build><item objectid="1"/></build></model>`,
  });
  const a = await analyze3MF(buf, JSZip);
  near(a.volumeCm3, 16.387064);
  near(a.sizeMm[0], 25.4);
  console.log('✔ cube-1inch.3mf', a.volumeCm3.toFixed(3), 'cm³');
}

// 4) Garbage input is rejected cleanly
await assert.rejects(analyze3MF(Buffer.from('not a zip'), JSZip), /valid 3MF/);
await fs.writeFile(path.join(dir, 'not-a-model.3mf'), 'not a zip');
console.log('✔ invalid file rejected');

console.log('\nAll checks passed. Sample files are in test/fixtures/.');
