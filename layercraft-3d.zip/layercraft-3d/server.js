import dotenv from 'dotenv';
import express from 'express';
import multer from 'multer';
import nodemailer from 'nodemailer';
import JSZip from 'jszip';
import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { analyze3MF, priceCustomItem, clampQty, roundCents, money } from './public/js/pricing.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
dotenv.config({ path: path.join(__dirname, '.env'), quiet: true });
const readJson = async (f) => JSON.parse(await fs.readFile(path.join(__dirname, f), 'utf8'));

const config = await readJson('config.json');
// Set "hidden": true on a product in products.json to take it off the site.
const products = (await readJson('products.json')).filter((p) => !p.hidden);

const PORT = Number(process.env.PORT) || 3000;
const ORDER_EMAIL = process.env.ORDER_EMAIL || 'sidharrthguha@gmail.com';
const ORDERS_DIR = path.join(__dirname, 'orders');
const PUBLIC_URL = (process.env.PUBLIC_URL || process.env.RENDER_EXTERNAL_URL || `http://localhost:${PORT}`).replace(/\/+$/, '');
// Gmail rejects messages over 25 MB, and attachments grow ~35% when encoded.
// Bigger orders get private download links in the email instead.
const MAX_ATTACHMENT_BYTES = 17 * 1024 * 1024;
const fmt = (n) => money(n, config.currency);

// ---------- Email ----------
// The sending method is picked from .env:
//   RESEND_API_KEY      Resend's HTTPS API. Works on hosts that block SMTP, like Render's free plan.
//   SMTP_USER/SMTP_PASS any SMTP server, e.g. Gmail with an app password.
//   neither             preview mode: the email is saved in the order's folder instead of sent.

const EMAIL_MODE = process.env.RESEND_API_KEY ? 'resend'
  : process.env.SMTP_USER && process.env.SMTP_PASS ? 'smtp'
  : 'preview';
const smtpPort = Number(process.env.SMTP_PORT) || 465;
const transport =
  EMAIL_MODE === 'smtp'
    ? nodemailer.createTransport({
        host: process.env.SMTP_HOST || 'smtp.gmail.com',
        port: smtpPort,
        secure: smtpPort === 465,
        auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
      })
    : nodemailer.createTransport({ streamTransport: true, buffer: true, newline: 'unix' });

/** Sends the order email. In preview mode, returns the raw message instead. */
async function sendEmail({ subject, text, html, replyTo, attachments }) {
  if (EMAIL_MODE === 'resend') {
    const res = await fetch(process.env.RESEND_API_URL || 'https://api.resend.com/emails', {
      method: 'POST',
      headers: { Authorization: `Bearer ${process.env.RESEND_API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        // Without your own domain, Resend only sends from onboarding@resend.dev to your account's email.
        from: process.env.EMAIL_FROM || `${config.businessName} Orders <onboarding@resend.dev>`,
        to: [ORDER_EMAIL],
        reply_to: replyTo.address,
        subject,
        text,
        html,
        attachments: attachments.map((a) => ({ filename: a.filename, content: a.content.toString('base64') })),
      }),
    });
    if (!res.ok) throw new Error(`Resend ${res.status}: ${await res.text()}`);
    return null;
  }
  const info = await transport.sendMail({
    from: { name: `${config.businessName} Orders`, address: process.env.SMTP_USER || 'orders@localhost' },
    to: ORDER_EMAIL,
    replyTo,
    subject,
    text,
    html,
    attachments,
  });
  return EMAIL_MODE === 'preview' ? info.message : null;
}

// ---------- Validation ----------

class UserError extends Error {}

const CUSTOMER_FIELDS = {
  firstName: { required: true, max: 80, label: 'First name' },
  lastName: { required: true, max: 80, label: 'Last name' },
  email: { required: true, max: 200, label: 'Email' },
  phone: { required: false, max: 40, label: 'Phone' },
  address1: { required: true, max: 200, label: 'Street address' },
  address2: { required: false, max: 200, label: 'Apt / suite' },
  city: { required: true, max: 100, label: 'City' },
  state: { required: true, max: 100, label: 'State' },
  zip: { required: true, max: 20, label: 'ZIP code' },
  notes: { required: false, max: 2000, label: 'Order notes' },
};

function parseJson(value, fallback) {
  if (value == null || value === '') return fallback;
  try {
    return JSON.parse(value);
  } catch {
    throw new UserError('The order data was malformed. Please refresh and try again.');
  }
}

function cleanCustomer(raw) {
  const out = {};
  for (const [key, rule] of Object.entries(CUSTOMER_FIELDS)) {
    const v = String(raw?.[key] ?? '').trim();
    if (rule.required && !v) throw new UserError(`${rule.label} is required.`);
    if (v.length > rule.max) throw new UserError(`${rule.label} is too long.`);
    out[key] = v;
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(out.email)) throw new UserError('Please enter a valid email address.');
  return out;
}

function makeOrderId() {
  const d = new Date();
  const date = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`;
  return `${config.orderPrefix}-${date}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
}

const safeName = (name) => name.replace(/[^\w.\- ]+/g, '_').slice(0, 120) || 'model.3mf';

// ---------- Email body ----------

const esc = (s) =>
  String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

function buildEmail(order) {
  const c = order.customer;
  const addressLines = [c.address1, c.address2, `${c.city}, ${c.state} ${c.zip}`].filter(Boolean);
  const size = (s) => s.map((n) => n.toFixed(1)).join(' × ') + ' mm';

  const text = [
    `NEW ORDER ${order.id}`,
    `Placed: ${new Date(order.createdAt).toLocaleString('en-US')}`,
    '',
    'CUSTOMER',
    `${c.firstName} ${c.lastName}`,
    c.email,
    ...(c.phone ? [c.phone] : []),
    ...addressLines,
    '',
    order.catalog.length ? 'SHOP PRODUCTS TO PRINT' : '',
    ...order.catalog.map((l) => `- ${l.qty} × ${l.name} (${l.color}) @ ${fmt(l.each)} = ${fmt(l.total)}`),
    order.catalog.length ? '' : '',
    order.custom.length ? `CUSTOM PRINTS (${order.filesAttached ? '3MF files attached' : 'download links below'})` : '',
    ...order.custom.map(
      (l) =>
        `- ${l.qty} × ${l.fileName}: ${l.material}, ${l.strength}, ${l.color}; ~${l.grams} g each` +
        `; ${l.pieces > 1 ? `${l.pieces} pieces, largest ` : ''}${size(l.sizeMm)}; @ ${fmt(l.each)} = ${fmt(l.total)}` +
        (l.slicedGrams ? `; slicer says ${l.slicedGrams} g` : '') +
        (l.notes ? `\n    Notes: ${l.notes}` : '') +
        (l.downloadUrl ? `\n    Download: ${l.downloadUrl}` : ''),
    ),
    '',
    `ESTIMATED TOTAL: ${fmt(order.total)}`,
    c.notes ? `\nORDER NOTES\n${c.notes}` : '',
  ]
    .filter((line, i, arr) => !(line === '' && arr[i - 1] === ''))
    .join('\n');

  const th = 'text-align:left;padding:8px;border-bottom:2px solid #ddd;font-size:13px;color:#555';
  const td = 'padding:8px;border-bottom:1px solid #eee;vertical-align:top;font-size:14px';
  const row = (cells) => `<tr>${cells.map((x) => `<td style="${td}">${x}</td>`).join('')}</tr>`;

  const catalogTable = order.catalog.length
    ? `<h3 style="margin:24px 0 8px">Shop products to print</h3>
       <table style="border-collapse:collapse;width:100%">
         <tr><th style="${th}">Product</th><th style="${th}">Color</th><th style="${th}">Qty</th><th style="${th}">Each</th><th style="${th}">Total</th></tr>
         ${order.catalog.map((l) => row([esc(l.name), esc(l.color), l.qty, fmt(l.each), `<b>${fmt(l.total)}</b>`])).join('')}
       </table>`
    : '';

  const customTable = order.custom.length
    ? `<h3 style="margin:24px 0 8px">Custom prints <span style="font-weight:normal;color:#777">(${order.filesAttached ? '3MF files attached' : 'too large to attach, use the download links'})</span></h3>
       <table style="border-collapse:collapse;width:100%">
         <tr><th style="${th}">File</th><th style="${th}">Settings</th><th style="${th}">Size / weight</th><th style="${th}">Qty</th><th style="${th}">Each</th><th style="${th}">Total</th></tr>
         ${order.custom
           .map((l) =>
             row([
               `<b>${esc(l.fileName)}</b>${l.notes ? `<br><i style="color:#666">“${esc(l.notes)}”</i>` : ''}` +
                 (l.downloadUrl ? `<br><a href="${esc(l.downloadUrl)}">Download 3MF</a>` : ''),
               `${esc(l.material)}<br>${esc(l.strength)}<br>${esc(l.color)}`,
               `${l.pieces > 1 ? `${l.pieces} pieces, largest<br>` : ''}${size(l.sizeMm)}<br>~${l.grams} g each${l.slicedGrams ? `<br><span style="color:#777">slicer: ${l.slicedGrams} g</span>` : ''}`,
               l.qty,
               fmt(l.each),
               `<b>${fmt(l.total)}</b>`,
             ]),
           )
           .join('')}
       </table>`
    : '';

  const html = `<!doctype html><html><body style="margin:0;background:#f6f4f0;font-family:-apple-system,Segoe UI,Helvetica,Arial,sans-serif;color:#1d1b18">
  <div style="max-width:680px;margin:0 auto;padding:24px">
    <div style="background:#fff;border-radius:12px;padding:28px;border:1px solid #e8e3da">
      <p style="margin:0;color:#c2410c;font-weight:600;font-size:13px;letter-spacing:.04em;text-transform:uppercase">New order · ${esc(config.businessName)}</p>
      <h2 style="margin:6px 0 4px">${esc(order.id)}</h2>
      <p style="margin:0;color:#666;font-size:14px">${esc(new Date(order.createdAt).toLocaleString('en-US'))}</p>

      <h3 style="margin:24px 0 8px">Customer</h3>
      <p style="margin:0;line-height:1.6;font-size:15px">
        <b>${esc(c.firstName)} ${esc(c.lastName)}</b><br>
        <a href="mailto:${esc(c.email)}">${esc(c.email)}</a>${c.phone ? `<br>${esc(c.phone)}` : ''}<br>
        ${addressLines.map(esc).join('<br>')}
      </p>

      ${catalogTable}
      ${customTable}

      <p style="margin:24px 0 0;font-size:18px;text-align:right">Estimated total: <b>${fmt(order.total)}</b></p>
      ${c.notes ? `<h3 style="margin:24px 0 8px">Order notes</h3><p style="margin:0;white-space:pre-wrap">${esc(c.notes)}</p>` : ''}
      <p style="margin:28px 0 0;color:#888;font-size:12px">Reply to this email to contact the customer directly.</p>
    </div>
  </div></body></html>`;

  return {
    subject: `New order ${order.id}: ${c.firstName} ${c.lastName} (${fmt(order.total)})`,
    text,
    html,
  };
}

// ---------- App ----------

const app = express();
// Behind Render's proxy, use the visitor's real IP for rate limiting.
if (process.env.RENDER || process.env.TRUST_PROXY) app.set('trust proxy', 1);

// Uploads stream to a temp folder instead of memory (free hosting has 512 MB of RAM).
const upload = multer({
  dest: path.join(os.tmpdir(), 'layercraft-uploads'),
  limits: { fileSize: config.maxFileMb * 1024 * 1024, files: config.maxCustomFiles, fieldSize: 1024 * 1024 },
});

// Simple spam protection: at most 8 order attempts per visitor every 10 minutes.
const RATE_WINDOW_MS = 10 * 60 * 1000;
const RATE_MAX = 8;
const attempts = new Map();
function rateLimit(req, res, next) {
  const now = Date.now();
  const recent = (attempts.get(req.ip) || []).filter((t) => now - t < RATE_WINDOW_MS);
  if (recent.length >= RATE_MAX)
    return res.status(429).json({ error: 'Too many orders from your connection. Please wait a few minutes and try again.' });
  recent.push(now);
  attempts.set(req.ip, recent);
  next();
}
setInterval(() => {
  const now = Date.now();
  for (const [ip, times] of attempts) if (times.every((t) => now - t >= RATE_WINDOW_MS)) attempts.delete(ip);
}, RATE_WINDOW_MS).unref();

app.get('/healthz', (req, res) => res.send('ok'));

app.use(express.static(path.join(__dirname, 'public')));
app.use('/vendor', express.static(path.join(__dirname, 'node_modules/jszip/dist')));

app.get('/api/catalog', (req, res) => res.json({ config, products }));

// Private download links for 3MF files too large to email. Each order has its own random token.
app.get('/order-files/:id/:token/:name', async (req, res) => {
  const { id, token, name } = req.params;
  if (!/^[\w-]+$/.test(id)) return res.sendStatus(404);
  try {
    const order = JSON.parse(await fs.readFile(path.join(ORDERS_DIR, id, 'order.json'), 'utf8'));
    const valid =
      typeof order.fileToken === 'string' &&
      token.length === order.fileToken.length &&
      crypto.timingSafeEqual(Buffer.from(token), Buffer.from(order.fileToken));
    const line = valid && order.custom.find((l) => l.savedAs === name);
    if (!line) return res.sendStatus(404);
    res.download(path.join(ORDERS_DIR, id, line.savedAs), line.fileName);
  } catch {
    res.sendStatus(404);
  }
});

app.post('/api/order', rateLimit, upload.array('files', config.maxCustomFiles), async (req, res, next) => {
  try {
    const rawCustomer = parseJson(req.body.customer, {});
    // Honeypot: a hidden field people never see but spam bots fill in.
    if (rawCustomer?.company_website) return res.json({ ok: true, orderId: makeOrderId(), total: 0 });
    const customer = cleanCustomer(rawCustomer);
    const cartIn = parseJson(req.body.cart, []);
    const customIn = parseJson(req.body.custom, []);
    const files = req.files || [];
    if (!Array.isArray(cartIn) || !Array.isArray(customIn)) throw new UserError('The order data was malformed.');
    if (customIn.length !== files.length) throw new UserError('Each custom print needs its 3MF file attached.');

    const catalog = cartIn.map((line) => {
      const p = products.find((x) => x.id === line?.productId);
      if (!p) throw new UserError('One of the products in your order is no longer available.');
      const qty = clampQty(line.qty);
      const color = p.colors.includes(line.color) ? line.color : p.colors[0];
      return { productId: p.id, name: p.name, color, qty, each: p.price, total: roundCents(p.price * qty) };
    });

    const custom = [];
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const opts = customIn[i] || {};
      if (!/\.3mf$/i.test(file.originalname)) throw new UserError(`${file.originalname} is not a .3mf file.`);
      let analysis;
      try {
        analysis = await analyze3MF(await fs.readFile(file.path), JSZip);
      } catch (e) {
        throw new UserError(`${file.originalname}: ${e.message}`);
      }
      const priced = priceCustomItem(analysis, opts, config);
      custom.push({
        fileName: safeName(file.originalname),
        savedAs: `${i + 1}-${safeName(file.originalname)}`,
        material: priced.material.name,
        strength: priced.strength.name,
        color: priced.color,
        qty: priced.qty,
        grams: priced.grams,
        each: priced.each,
        total: priced.total,
        sizeMm: analysis.sizeMm.map((n) => Math.round(n * 10) / 10),
        pieces: analysis.itemSizesMm.length,
        volumeCm3: Math.round(analysis.volumeCm3 * 100) / 100,
        slicedGrams: analysis.slicedGrams,
        notes: String(opts.notes ?? '').trim().slice(0, 500),
      });
    }

    if (!catalog.length && !custom.length) throw new UserError('Your order is empty.');

    const filesAttached = files.reduce((s, f) => s + f.size, 0) <= MAX_ATTACHMENT_BYTES;
    const order = {
      id: makeOrderId(),
      fileToken: crypto.randomBytes(16).toString('hex'),
      filesAttached,
      createdAt: new Date().toISOString(),
      customer,
      catalog,
      custom,
      total: roundCents([...catalog, ...custom].reduce((s, l) => s + l.total, 0)),
    };
    if (!filesAttached) {
      for (const l of custom) l.downloadUrl = `${PUBLIC_URL}/order-files/${order.id}/${order.fileToken}/${encodeURIComponent(l.savedAs)}`;
    }

    // Always keep a copy on disk, so no order is lost even if email fails.
    const dir = path.join(ORDERS_DIR, order.id);
    await fs.mkdir(dir, { recursive: true });
    await Promise.all(files.map((f, i) => fs.copyFile(f.path, path.join(dir, custom[i].savedAs))));
    await fs.writeFile(path.join(dir, 'order.json'), JSON.stringify(order, null, 2));

    const email = buildEmail(order);
    const attachments = filesAttached
      ? await Promise.all(custom.map(async (l) => ({ filename: l.fileName, content: await fs.readFile(path.join(dir, l.savedAs)) })))
      : [];
    const preview = await sendEmail({
      ...email,
      replyTo: { name: `${customer.firstName} ${customer.lastName}`, address: customer.email },
      attachments,
    }).catch(async (err) => {
      console.error(`✖ Order ${order.id} saved, but the email FAILED:`, err.message);
      await fs.writeFile(path.join(dir, 'EMAIL_FAILED.txt'), String(err.stack || err));
      throw new Error('email failed');
    });

    if (preview) {
      await fs.writeFile(path.join(dir, 'email-preview.eml'), preview);
      console.warn(`⚠ Order ${order.id} saved to orders/${order.id}/. Email isn't set up, so nothing was sent (see README).`);
    } else {
      console.log(`✔ Order ${order.id} emailed to ${ORDER_EMAIL} (${fmt(order.total)})`);
    }

    res.json({ ok: true, orderId: order.id, total: order.total });
  } catch (err) {
    next(err);
  } finally {
    for (const f of req.files || []) fs.unlink(f.path).catch(() => {});
  }
});

app.use((err, req, res, next) => {
  if (err instanceof UserError) return res.status(400).json({ error: err.message });
  if (err instanceof multer.MulterError) {
    const msg =
      err.code === 'LIMIT_FILE_SIZE' ? `Each file must be under ${config.maxFileMb} MB.`
      : err.code === 'LIMIT_FILE_COUNT' ? `You can upload up to ${config.maxCustomFiles} files per order.`
      : 'There was a problem with your upload.';
    return res.status(400).json({ error: msg });
  }
  if (err.message !== 'email failed') console.error(err);
  res.status(500).json({ error: 'We couldn’t submit your order just now. Please try again in a minute.' });
});

app.listen(PORT, () => {
  console.log(`${config.businessName} is running at http://localhost:${PORT}`);
  console.log(
    EMAIL_MODE === 'preview'
      ? `⚠ Email isn't set up yet. Orders will be saved to ./orders only (see README).`
      : `Orders will be emailed to ${ORDER_EMAIL} via ${EMAIL_MODE === 'resend' ? 'Resend' : 'SMTP'}`,
  );
});
