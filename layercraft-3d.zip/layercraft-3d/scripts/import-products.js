// Turns every .3mf in source-models/ into a shop product.
//
//   npm run import-products
//
// For each file it reads the title, designer and license saved by Bambu Studio,
// saves the plate preview as the product photo, and prices it from the slicer's
// filament weight (or our own estimate) at the PLA price per gram.
//
// Products already in products.json are left exactly as they are, so your edits
// to names, prices and descriptions are safe. Delete a product's entry (and
// re-run) to regenerate it. Placeholder products are removed.
import JSZip from 'jszip';
import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { analyze3MF, estimateGrams } from '../public/js/pricing.js';

const root = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
const SOURCE_DIR = path.join(root, 'source-models');
const IMAGE_DIR = path.join(root, 'public/images/products');
const PRODUCTS_FILE = path.join(root, 'products.json');

const config = JSON.parse(await fs.readFile(path.join(root, 'config.json'), 'utf8'));
const existing = JSON.parse(await fs.readFile(PRODUCTS_FILE, 'utf8'));

// Licenses that allow selling prints (with credit to the designer).
const COMMERCIAL_OK = /^(CC[- ]?)?(BY|BY-SA|CC0|Public Domain)$/i;

const decode = (s) => {
  let out = String(s ?? '');
  for (let i = 0; i < 3; i++) {
    out = out
      .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#0*39;|&apos;/g, "'")
      .replace(/&#(\d+);/g, (_, n) => String.fromCharCode(+n)).replace(/&amp;/g, '&');
  }
  return out;
};
const stripTags = (s) => s.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
const slug = (s) => s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 60);

function cleanTitle(raw, fileName) {
  let t = stripTags(decode(raw)) || path.basename(fileName, '.3mf').replace(/\(\d+\)$/, '').replace(/_/g, ' ');
  t = t.split('|')[0]
    .replace(/,?\s*\bno ams\b/i, '')
    .replace(/\s+-\s+/g, ' ')
    .replace(/\b(A1|A1 mini|P1S|P1P|X1C|X1)\b/g, '')
    .replace(/\s+/g, ' ')
    .trim();
  // Title-case lower-case words ("Simple & clean pen holder"), leaving short ones like "cm" and "or".
  return t.replace(/\b[a-z]{3,}\b/g, (w) => (['and', 'the', 'for', 'with'].includes(w) ? w : w[0].toUpperCase() + w.slice(1)));
}

function guessCategory(name) {
  if (/pencil case|ruler|dispenser|school/i.test(name)) return 'School';
  if (/organi[sz]er|holder|divider|caddy|stand|tray/i.test(name)) return 'Organizers';
  return 'Other';
}

const cm = (mm) => (mm / 10).toFixed(mm < 100 ? 1 : 0);

const files = (await fs.readdir(SOURCE_DIR)).filter((f) => /\.3mf$/i.test(f)).sort();
const seenHashes = new Set();
const found = new Map(); // id -> product

for (const file of files) {
  const buf = await fs.readFile(path.join(SOURCE_DIR, file));
  const hash = crypto.createHash('sha1').update(buf).digest('hex');
  if (seenHashes.has(hash)) {
    console.log(`  skip  ${file} (identical copy of another file)`);
    continue;
  }
  seenHashes.add(hash);

  const zip = await JSZip.loadAsync(buf);
  const model = (await zip.file(/(^|\/)3dmodel\.model$/i)[0]?.async('string')) || '';
  const meta = {};
  for (const m of model.matchAll(/<metadata name="([^"]+)"[^>]*>([^<]*)</g)) meta[m[1]] = decode(m[2]).trim();

  let analysis;
  try {
    analysis = await analyze3MF(buf, JSZip);
  } catch (e) {
    console.log(`  skip  ${file}: ${e.message}`);
    continue;
  }

  const name = cleanTitle(meta.Title, file);
  const id = slug(name) || slug(file);
  const pla = config.materials.find((m) => m.id === 'pla') ?? config.materials[0];
  const standard = config.strengths.find((s) => s.default) ?? config.strengths[0];
  const grams = analysis.slicedGrams ?? estimateGrams(analysis, pla, standard, config);
  const price = Math.ceil(Math.max(config.minimumPerPart, grams * pla.pricePerGram));

  // Prefer the file saved with slicer results (it has the real filament weight).
  const prev = found.get(id);
  if (prev) {
    if (prev._sliced || !analysis.slicedGrams) {
      console.log(`  skip  ${file} (another version of "${name}")`);
      continue;
    }
    console.log(`  skip  ${prev.sourceFile} (newer version of "${name}" found)`);
  }

  const pieces = analysis.itemSizesMm.length;
  const [w, d, h] = analysis.sizeMm;
  const description = stripTags(decode(meta.Description || ''))
    .replace(/^(now available new version!+|boost me)\s*/i, '')
    .split(/(?<=[.!?])\s/)
    .find((s) => s.length > 30 && !/https?:|www\.|\bI\b|\bmy\b/i.test(s))
    ?.slice(0, 160);

  found.set(id, {
    id,
    name,
    category: guessCategory(name),
    price,
    description: description || `${name}, printed to order.`,
    // Multi-piece kits are printed flat and assembled, so a piece's size would mislead.
    specs: `${pla.name} · ${pieces > 1 ? `${pieces} pieces` : `${cm(w)} × ${cm(d)} × ${cm(h)} cm`} · ~${Math.round(grams)} g`,
    colors: config.colors.slice(0, 6),
    image: `images/products/${id}.png`,
    designer: meta.Designer || '',
    license: meta.License || '',
    sourceFile: file,
    _sliced: Boolean(analysis.slicedGrams),
    _zip: zip,
  });
}

await fs.mkdir(IMAGE_DIR, { recursive: true });
const keep = existing.filter((p) => !p.placeholder);
const keptIds = new Set(keep.map((p) => p.id));
const added = [];

for (const p of found.values()) {
  if (keptIds.has(p.id)) continue;
  const img = p._zip.file('Metadata/plate_1.png') || p._zip.file('Metadata/thumbnail.png') || p._zip.file(/plate_\d+\.png$/)[0];
  if (img) await fs.writeFile(path.join(root, 'public', p.image), await img.async('nodebuffer'));
  else p.image = 'images/logo.svg';
  delete p._zip;
  delete p._sliced;
  added.push(p);
}

await fs.writeFile(PRODUCTS_FILE, JSON.stringify([...keep, ...added], null, 2) + '\n');

console.log(`\nAdded ${added.length} product(s); kept ${keep.length}; removed ${existing.length - keep.length} placeholder(s).\n`);
for (const p of added) {
  const ok = COMMERCIAL_OK.test(p.license.trim());
  console.log(`  ${ok ? '✔' : '⚠'} ${p.name}: $${p.price}  (${p.specs})`);
  console.log(`      design by ${p.designer || 'unknown'} · license: ${p.license || 'none listed'}${ok ? '' : ' → does not allow selling prints without the designer’s permission'}`);
}
