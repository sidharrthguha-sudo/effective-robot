# LayerCraft 3D (placeholder name)

Website for a 3D printing business:

- **Shop:** showcases your products with colors and quantities.
- **Custom prints:** customers upload `.3mf` files and get an instant price by the gram. The site measures the model's volume, then prices it by material and strength.
- **Checkout:** collects first/last name, email, phone (optional), and shipping address.
- **Email:** every order goes to **sidharrthguha@gmail.com** with the customer's contact info, every item to print, and the 3MF files attached. Hit *Reply* to email the customer.
- A copy of every order (details and 3MF files) is also saved in `orders/<order-id>/`, so nothing is lost if an email fails.

No payment is taken on the site. You confirm the final price with the customer by email first.

## Run it

Requires Node.js 18+.

```bash
npm install
npm start
```

Open http://localhost:3000 (or set `PORT` in `.env`).

## Turn on email (one-time setup)

Until you do this, orders are saved to `orders/` with an `email-preview.eml` file (the exact email that would have been sent), and nothing is emailed.

1. Use any Gmail account to send from (it can be sidharrthguha@gmail.com itself).
2. Turn on **2-Step Verification** for that Google account.
3. Create an **App Password**: Google Account → Security → 2-Step Verification → *App passwords*.
4. Copy `.env.example` to `.env`, then fill in `SMTP_USER` (the Gmail address) and `SMTP_PASS` (the 16-character app password).
5. Restart with `npm start`. The console should say `Orders will be emailed to sidharrthguha@gmail.com`.

To send orders somewhere else, change `ORDER_EMAIL` in `.env`.

## Customize

| What | Where |
| --- | --- |
| Business name, tagline, order-number prefix | `config.json` → `businessName`, `tagline`, `orderPrefix` |
| Price per gram, materials | `config.json` → `materials[].pricePerGram` |
| Minimum charge per part | `config.json` → `minimumPerPart` |
| Colors offered for custom prints | `config.json` → `colors` |
| Printer size (warns on oversized models) | `config.json` → `buildVolumeMm` |
| Products (name, price, colors, photo) | `products.json` (or import them, see below) |
| Product photos | put images in `public/images/` and point `image` at them |

Restart the server after editing `config.json` or `products.json`.

### How custom prices are calculated

```
shell       = surface area × shellMm            (walls, top and bottom, printed solid)
grams       = density × (shell + infill% × (volume − shell))
price each  = max(minimumPerPart, grams × pricePerGram)
```

With `shellMm: 1.0`, this lands within about 1% of Bambu Studio's own filament weight on the test files (for example, the paper organizer is 459 g estimated vs 456 g from the slicer). The server recalculates every price from the uploaded file, so customers can't change prices in their browser. If a 3MF was saved after slicing, the slicer's weight also appears in the email for reference.

If an order's files add up to more than ~17 MB (too big for Gmail), the email includes private download links instead of attachments. Set `PUBLIC_URL` in `.env` so those links point to your live site.

## Adding shop products from 3MF files

1. Put `.3mf` files in `source-models/`.
2. Run `npm run import-products`.

Each file becomes a product with its name, a preview picture, its weight and a price (PLA price per gram, rounded up), plus a "Design by …" credit. Duplicate files are skipped. Products already in `products.json` are left alone, so your edits are safe. The command also prints each design's license. **Only sell prints of designs whose license allows it** (for example CC BY, credited to the designer), or that you designed or have permission for. MakerWorld's "Standard Digital File License" and any "NC" (non-commercial) license don't allow selling prints.

## Going live on Render

1. **Put the code on GitHub.** Make a free account at github.com. In GitHub Desktop, choose *File → Add Local Repository* → this folder → *Publish repository* (keep it private if you like).
2. **Get an email key.** Sign up at resend.com using **sidharrthguha@gmail.com**, then *API Keys → Create API Key* and copy it. (Render's free plan blocks Gmail SMTP, so the live site emails through Resend instead.)
3. **Deploy.** Sign up at render.com with GitHub. Choose *New → Blueprint*, pick the repo, paste the Resend key when asked for `RESEND_API_KEY`, and click *Apply*. A few minutes later the site is live at `https://layercraft-3d.onrender.com` (or similar).
4. **Test it** by placing an order yourself and checking your inbox.

Every time you push a change to GitHub, Render redeploys automatically.

Good to know about the free plan:
- The site sleeps after 15 minutes without visitors. The next visit takes about a minute to load. Render's paid Starter plan ($7/month) keeps it awake.
- The server's disk is wiped on every restart, so `orders/` there is temporary. The email is your permanent record. Download links for very large orders only work until the next restart.

**Your own domain (optional):** buy one (about $10–15/year, e.g. from Cloudflare or Namecheap). Add it in Render under *Settings → Custom Domains*. To send email from it, verify the domain in Resend and set `EMAIL_FROM` (see `.env.example`).

## Test

```bash
npm test
```

This builds sample 3MF files in `test/fixtures/` and checks the volume, size, and price math.
