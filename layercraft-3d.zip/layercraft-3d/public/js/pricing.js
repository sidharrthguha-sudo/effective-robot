// Shared by the browser (app.js) and the server (server.js), so the price a
// customer sees while uploading is exactly the price the server recalculates.
//
// A .3mf file is a zip containing XML meshes. We read every printable mesh,
// apply its build transforms, and compute its volume, surface area and size.
// Weight = density x (solid outer shell + infill x the rest of the volume),
// where the shell is surface area x wall thickness. This tracks Bambu Studio's
// own filament estimates to within a few percent.

const UNIT_TO_CM = { micron: 1e-4, millimeter: 0.1, centimeter: 1, inch: 2.54, foot: 30.48, meter: 100 };
const IDENTITY = [1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0];
const MAX_UNCOMPRESSED_BYTES = 200 * 1024 * 1024; // keeps a 512 MB server safe

const RX = {
  model: /<(?:[\w-]+:)?model\b[^>]*\bunit="(\w+)"/,
  object: /<(?:[\w-]+:)?object\b([^>]*?)(?:\/>|>([\s\S]*?)<\/(?:[\w-]+:)?object>)/g,
  mesh: /<(?:[\w-]+:)?mesh\b/,
  vertex: /<(?:[\w-]+:)?vertex\b([^>]*)>/g,
  triangle: /<(?:[\w-]+:)?triangle\b([^>]*)>/g,
  component: /<(?:[\w-]+:)?component\b([^>]*)>/g,
  build: /<(?:[\w-]+:)?build\b[^>]*>([\s\S]*?)<\/(?:[\w-]+:)?build>/,
  item: /<(?:[\w-]+:)?item\b([^>]*)>/g,
  rel: /<Relationship\b([^>]*)>/g,
  x: /\bx="([^"]*)"/, y: /\by="([^"]*)"/, z: /\bz="([^"]*)"/,
  v1: /\bv1="(\d+)"/, v2: /\bv2="(\d+)"/, v3: /\bv3="(\d+)"/,
};

function attrs(str) {
  const out = {};
  for (const m of str.matchAll(/([\w:-]+)\s*=\s*"([^"]*)"/g)) {
    out[m[1]] = m[2];
    const local = m[1].split(':').pop(); // p:path -> path
    if (!(local in out)) out[local] = m[2];
  }
  return out;
}

function parseTransform(s) {
  if (!s) return IDENTITY;
  const n = s.trim().split(/\s+/).map(Number);
  return n.length === 12 && n.every(Number.isFinite) ? n : IDENTITY;
}

// 3MF transforms are row-major 4x3 (row vectors). mul(a, b) = apply a, then b.
function mul(a, b) {
  const r = new Array(12);
  for (let i = 0; i < 3; i++)
    for (let j = 0; j < 3; j++) r[i * 3 + j] = a[i * 3] * b[j] + a[i * 3 + 1] * b[3 + j] + a[i * 3 + 2] * b[6 + j];
  for (let j = 0; j < 3; j++) r[9 + j] = a[9] * b[j] + a[10] * b[3 + j] + a[11] * b[6 + j] + b[9 + j];
  return r;
}

const det = (m) =>
  m[0] * (m[4] * m[8] - m[5] * m[7]) - m[1] * (m[3] * m[8] - m[5] * m[6]) + m[2] * (m[3] * m[7] - m[4] * m[6]);

function parseMesh(body) {
  const v = [];
  for (const m of body.matchAll(RX.vertex)) {
    const a = m[1];
    v.push(+(RX.x.exec(a)?.[1] ?? NaN), +(RX.y.exec(a)?.[1] ?? NaN), +(RX.z.exec(a)?.[1] ?? NaN));
  }
  const verts = Float64Array.from(v);
  const count = verts.length / 3;
  let volume = 0;
  let area = 0;
  let triCount = 0;
  for (const m of body.matchAll(RX.triangle)) {
    const i = +RX.v1.exec(m[1])?.[1], j = +RX.v2.exec(m[1])?.[1], k = +RX.v3.exec(m[1])?.[1];
    if (!(i < count && j < count && k < count)) continue;
    const ax = verts[i * 3], ay = verts[i * 3 + 1], az = verts[i * 3 + 2];
    const bx = verts[j * 3], by = verts[j * 3 + 1], bz = verts[j * 3 + 2];
    const cx = verts[k * 3], cy = verts[k * 3 + 1], cz = verts[k * 3 + 2];
    volume += ax * (by * cz - bz * cy) - ay * (bx * cz - bz * cx) + az * (bx * cy - by * cx);
    const ux = bx - ax, uy = by - ay, uz = bz - az, wx = cx - ax, wy = cy - ay, wz = cz - az;
    area += Math.hypot(uy * wz - uz * wy, uz * wx - ux * wz, ux * wy - uy * wx) / 2;
    triCount++;
  }
  return { verts, triCount, volume: volume / 6, area };
}

function parseModel(xml) {
  const unit = RX.model.exec(xml)?.[1] || 'millimeter';
  const objects = new Map();
  for (const m of xml.matchAll(RX.object)) {
    const a = attrs(m[1]);
    const body = m[2] || '';
    const obj = { type: a.type || 'model', mesh: null, components: [] };
    if (RX.mesh.test(body)) obj.mesh = parseMesh(body);
    for (const c of body.matchAll(RX.component)) {
      const ca = attrs(c[1]);
      obj.components.push({ id: ca.objectid, path: ca.path, transform: parseTransform(ca.transform) });
    }
    objects.set(a.id, obj);
  }
  const items = [];
  const build = RX.build.exec(xml);
  if (build) {
    for (const it of build[1].matchAll(RX.item)) {
      const a = attrs(it[1]);
      if (a.printable === '0') continue;
      items.push({ id: a.objectid, path: a.path, transform: parseTransform(a.transform) });
    }
  }
  return { unit, objects, items };
}

const normPath = (p) => String(p || '').replace(/^\/+/, '').toLowerCase();

/**
 * Analyze a .3mf file.
 * @param data ArrayBuffer | Uint8Array | Buffer
 * @param JSZip the JSZip class (global in the browser, imported on the server)
 * @returns {{volumeCm3:number, areaCm2:number, sizeMm:number[], itemSizesMm:number[][], triangles:number,
 *            parts:number, slicedGrams:number|null}}
 * sizeMm is the bulkiest single object. Slicer projects spread objects over
 * several plates, so the overall extent of the file isn't a meaningful size.
 */
export async function analyze3MF(data, JSZip) {
  let zip;
  try {
    zip = await JSZip.loadAsync(data);
  } catch {
    throw new Error('This isn’t a valid 3MF file (it couldn’t be opened).');
  }

  const entries = {};
  let uncompressed = 0;
  zip.forEach((p, f) => {
    if (f.dir) return;
    entries[normPath(p)] = f;
    uncompressed += f._data?.uncompressedSize || 0;
  });
  if (uncompressed > MAX_UNCOMPRESSED_BYTES) throw new Error('This 3MF file is too large to process.');
  const read = (p) => entries[normPath(p)]?.async('string') ?? null;

  let rootPath = '3D/3dmodel.model';
  const rels = await read('_rels/.rels');
  if (rels) {
    for (const m of rels.matchAll(RX.rel)) {
      const a = attrs(m[1]);
      if (/3dmodel/i.test(a.Type || '') && a.Target) { rootPath = a.Target; break; }
    }
  }

  const models = new Map();
  async function model(p) {
    const key = normPath(p);
    if (!models.has(key)) {
      const xml = await read(key);
      models.set(key, xml ? parseModel(xml) : null);
    }
    return models.get(key);
  }

  const root = await model(rootPath);
  if (!root) throw new Error('No 3D model was found inside this 3MF file.');
  const cmPerUnit = UNIT_TO_CM[root.unit] ?? 0.1;

  const acc = { volume: 0, area: 0, triangles: 0, parts: 0 };

  async function walk(path, id, world, depth, box) {
    if (depth > 32) return;
    const obj = (await model(path))?.objects.get(id);
    if (!obj || obj.type === 'support' || obj.type === 'other') return;
    if (obj.mesh && obj.mesh.triCount) {
      const d = Math.abs(det(world));
      acc.volume += Math.abs(obj.mesh.volume) * d;
      acc.area += obj.mesh.area * Math.cbrt(d * d); // exact for uniform scaling
      acc.triangles += obj.mesh.triCount;
      acc.parts++;
      const v = obj.mesh.verts;
      const w = world;
      for (let i = 0; i < v.length; i += 3) {
        const x = v[i], y = v[i + 1], z = v[i + 2];
        const p0 = x * w[0] + y * w[3] + z * w[6] + w[9];
        const p1 = x * w[1] + y * w[4] + z * w[7] + w[10];
        const p2 = x * w[2] + y * w[5] + z * w[8] + w[11];
        if (p0 < box.min[0]) box.min[0] = p0; if (p0 > box.max[0]) box.max[0] = p0;
        if (p1 < box.min[1]) box.min[1] = p1; if (p1 > box.max[1]) box.max[1] = p1;
        if (p2 < box.min[2]) box.min[2] = p2; if (p2 > box.max[2]) box.max[2] = p2;
      }
    }
    for (const c of obj.components) await walk(c.path || path, c.id, mul(c.transform, world), depth + 1, box);
  }

  const items = root.items.length ? root.items : [...root.objects.keys()].map((id) => ({ id, transform: IDENTITY }));
  const itemSizesMm = [];
  for (const it of items) {
    const box = { min: [Infinity, Infinity, Infinity], max: [-Infinity, -Infinity, -Infinity] };
    await walk(it.path || rootPath, it.id, it.transform, 0, box);
    if (box.max[0] >= box.min[0]) itemSizesMm.push([0, 1, 2].map((k) => (box.max[k] - box.min[k]) * cmPerUnit * 10));
  }

  if (!acc.parts || !(acc.volume > 0)) throw new Error('No printable geometry was found in this 3MF file.');

  // Files saved after slicing (e.g. Bambu Studio) report the slicer's own filament
  // weight. We pass it along for reference; pricing always uses the geometry.
  let slicedGrams = null;
  const slice = await read('Metadata/slice_info.config');
  if (slice) {
    let g = 0;
    for (const m of slice.matchAll(/\bused_g="([\d.]+)"/g)) g += +m[1];
    if (g > 0) slicedGrams = Math.round(g * 10) / 10;
  }

  return {
    volumeCm3: acc.volume * cmPerUnit ** 3,
    areaCm2: acc.area * cmPerUnit ** 2,
    sizeMm: itemSizesMm.reduce((a, b) => (b[0] * b[1] * b[2] > a[0] * a[1] * a[2] ? b : a)),
    itemSizesMm,
    triangles: acc.triangles,
    parts: acc.parts,
    slicedGrams,
  };
}

export const clampQty = (q) => Math.min(99, Math.max(1, Math.floor(Number(q)) || 1));
export const roundCents = (n) => Math.round(n * 100) / 100;

export function money(n, currency = 'USD') {
  return new Intl.NumberFormat('en-US', { style: 'currency', currency }).format(n);
}

/** True if an object of this size fits the printer in some axis-aligned orientation. */
export function fitsBuildVolume(sizeMm, buildMm) {
  const a = [...sizeMm].sort((x, y) => y - x);
  const b = [...buildMm].sort((x, y) => y - x);
  return a.every((v, i) => v <= b[i] + 0.01);
}

/** Filament weight: solid walls/skins (area x shellMm) plus infill for the interior. */
export function estimateGrams(analysis, material, strength, config) {
  const volume = analysis.volumeCm3;
  const shell = Math.min(volume, analysis.areaCm2 * ((config.shellMm ?? 1) / 10));
  return material.density * (shell + strength.infill * (volume - shell));
}

/** Price one uploaded model. opts = { material, strength, color, qty } (ids from config). */
export function priceCustomItem(analysis, opts, config) {
  const material = config.materials.find((m) => m.id === opts.material) ?? config.materials[0];
  const strength =
    config.strengths.find((s) => s.id === opts.strength) ?? config.strengths.find((s) => s.default) ?? config.strengths[0];
  const color = config.colors.includes(opts.color) ? opts.color : config.colors[0];
  const qty = clampQty(opts.qty);
  const grams = estimateGrams(analysis, material, strength, config);
  const each = roundCents(Math.max(config.minimumPerPart, grams * material.pricePerGram));
  return { material, strength, color, qty, grams: Math.round(grams * 10) / 10, each, total: roundCents(each * qty) };
}
