import { analyze3MF, priceCustomItem, fitsBuildVolume, clampQty, roundCents, money } from './pricing.js';

const state = {
  config: null,
  products: [],
  category: 'All',
  cart: [], // { key, productId, color, qty }
  custom: [], // { id, file, status: 'analyzing'|'ready'|'error', analysis, error, opts, el }
};
let nextId = 1;

const $ = (sel, el = document) => el.querySelector(sel);
const fmt = (n) => money(n, state.config?.currency);
const esc = (s) =>
  String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
const options = (list, selected) =>
  list.map(({ value, label }) => `<option value="${esc(value)}"${value === selected ? ' selected' : ''}>${esc(label)}</option>`).join('');

// ---------------- Boot ----------------

init();

async function init() {
  drawHeroLayers();
  $('#year').textContent = new Date().getFullYear();
  try {
    const res = await fetch('/api/catalog');
    if (!res.ok) throw new Error();
    const data = await res.json();
    state.config = data.config;
    state.products = data.products;
  } catch {
    $('#product-grid').innerHTML = '<p class="form-error">Couldn’t load the shop. Please refresh the page.</p>';
    return;
  }
  const c = state.config;
  document.querySelectorAll('[data-bind="businessName"]').forEach((el) => (el.textContent = c.businessName));
  document.querySelectorAll('[data-bind="tagline"]').forEach((el) => (el.textContent = c.tagline));
  document.title = `${c.businessName} · Custom 3D Printing`;
  $('#min-part').textContent = fmt(c.minimumPerPart);
  $('#drop-limits').textContent = `Up to ${c.maxCustomFiles} files, ${c.maxFileMb} MB each`;
  $('#rate-rows').innerHTML = c.materials
    .map((m) => `<tr><td>${esc(m.name)}</td><td>${fmt(m.pricePerGram)}/g</td><td class="hide-sm">${esc(m.note || '')}</td></tr>`)
    .join('');

  renderChips();
  renderProducts();
  setupDropzone();
  setupForm();
  renderSummary();
}

function drawHeroLayers() {
  const widths = [110, 124, 136, 146, 152, 154, 150, 142, 130, 116, 104, 96, 92];
  $('#hero-layers').innerHTML = widths
    .map((w, i) => {
      const y = 334 - 13 * (i + 1) + 1;
      const cls = i === widths.length - 1 ? 'layer printing' : 'layer';
      return `<rect class="${cls}" x="${210 - w / 2}" y="${y}" width="${w}" height="12" rx="5"/>`;
    })
    .join('');
}

// ---------------- Shop ----------------

function renderChips() {
  const cats = ['All', ...new Set(state.products.map((p) => p.category))];
  const wrap = $('#category-chips');
  wrap.innerHTML = cats
    .map((c) => `<button type="button" class="chip" aria-pressed="${c === state.category}" data-cat="${esc(c)}">${esc(c)}</button>`)
    .join('');
  wrap.onclick = (e) => {
    const btn = e.target.closest('.chip');
    if (!btn) return;
    state.category = btn.dataset.cat;
    renderChips();
    renderProducts();
  };
}

function renderProducts() {
  const grid = $('#product-grid');
  const list = state.products.filter((p) => state.category === 'All' || p.category === state.category);
  grid.innerHTML = list
    .map(
      (p) => `
      <article class="product" data-id="${esc(p.id)}">
        <div class="product-media"><img src="${esc(p.image)}" alt="${esc(p.name)}" loading="lazy" width="400" height="300"></div>
        <div class="product-body">
          <span class="tag">${esc(p.category)}</span>
          <div class="product-top"><h3>${esc(p.name)}</h3><span class="price">${fmt(p.price)}</span></div>
          <p class="desc">${esc(p.description)}</p>
          <p class="specs">${esc(p.specs || '')}</p>
          ${p.designer ? `<p class="credit">Design by ${esc(p.designer)}</p>` : ''}
          <div class="product-actions">
            <label><span class="sr-only">Color for ${esc(p.name)}</span>
              <select class="p-color">${options(p.colors.map((c) => ({ value: c, label: c })))}</select></label>
            <label><span class="sr-only">Quantity for ${esc(p.name)}</span>
              <input class="p-qty" type="number" min="1" max="99" value="1" inputmode="numeric"></label>
            <button class="btn btn-primary btn-sm p-add" type="button">Add</button>
          </div>
        </div>
      </article>`,
    )
    .join('');

  grid.onclick = (e) => {
    const btn = e.target.closest('.p-add');
    if (!btn) return;
    const card = btn.closest('.product');
    const product = state.products.find((p) => p.id === card.dataset.id);
    const color = $('.p-color', card).value;
    const qty = clampQty($('.p-qty', card).value);
    addToCart(product, color, qty);
    $('.p-qty', card).value = 1;
  };
}

function addToCart(product, color, qty) {
  const key = `${product.id}|${color}`;
  const line = state.cart.find((l) => l.key === key);
  if (line) line.qty = clampQty(line.qty + qty);
  else state.cart.push({ key, productId: product.id, color, qty });
  toast(`Added ${qty} × ${product.name} (${color})`);
  renderSummary();
}

// ---------------- Custom 3MF uploads ----------------

function setupDropzone() {
  const zone = $('#dropzone');
  const input = $('#file-input');
  input.addEventListener('change', () => {
    addFiles([...input.files]);
    input.value = '';
  });
  ['dragenter', 'dragover'].forEach((ev) =>
    zone.addEventListener(ev, (e) => {
      e.preventDefault();
      zone.classList.add('drag');
    }),
  );
  ['dragleave', 'drop'].forEach((ev) => zone.addEventListener(ev, () => zone.classList.remove('drag')));
  zone.addEventListener('drop', (e) => {
    e.preventDefault();
    addFiles([...e.dataTransfer.files]);
  });
  // Don't let a file dropped slightly outside the zone navigate away from the page.
  window.addEventListener('dragover', (e) => e.preventDefault());
  window.addEventListener('drop', (e) => e.preventDefault());
}

function addFiles(files) {
  const c = state.config;
  for (const file of files) {
    if (state.custom.length >= c.maxCustomFiles) {
      toast(`You can upload up to ${c.maxCustomFiles} files per order.`);
      break;
    }
    const item = {
      id: nextId++,
      file,
      status: 'analyzing',
      analysis: null,
      error: null,
      opts: {
        material: c.materials[0].id,
        strength: (c.strengths.find((s) => s.default) ?? c.strengths[0]).id,
        color: c.colors[0],
        qty: 1,
        notes: '',
      },
    };
    if (!/\.3mf$/i.test(file.name)) {
      item.status = 'error';
      item.error = 'Only .3mf files are supported. Export your model as 3MF from your CAD or slicer app.';
    } else if (file.size > c.maxFileMb * 1024 * 1024) {
      item.status = 'error';
      item.error = `This file is larger than ${c.maxFileMb} MB.`;
    }
    state.custom.push(item);
    createCustomRow(item);
    if (item.status === 'analyzing') analyze(item);
  }
  renderSummary();
}

async function analyze(item) {
  try {
    if (!window.JSZip) throw new Error('The file reader didn’t load. Please refresh the page.');
    item.analysis = await analyze3MF(await item.file.arrayBuffer(), window.JSZip);
    item.status = 'ready';
  } catch (e) {
    item.status = 'error';
    item.error = e.message || 'We couldn’t read this file.';
  }
  if (!state.custom.includes(item)) return; // removed while analyzing
  updateCustomRow(item);
  renderSummary();
}

function createCustomRow(item) {
  const c = state.config;
  const el = document.createElement('div');
  el.className = 'upload-item';
  el.innerHTML = `
    <div class="upload-head">
      <div class="file-icon" aria-hidden="true">3MF</div>
      <div><strong>${esc(item.file.name)}</strong><div class="fmeta"></div></div>
      <button type="button" class="icon-btn remove" aria-label="Remove ${esc(item.file.name)}">×</button>
    </div>
    <div class="upload-body" hidden>
      <div class="stats">
        <div><span class="s-size-label">Size</span><b class="s-size"></b></div>
        <div><span>Volume</span><b class="s-vol"></b></div>
        <div><span>Est. weight</span><b class="s-grams"></b></div>
        <div><span>Price each</span><b class="s-each"></b></div>
      </div>
      <p class="warn" hidden></p>
      <div class="opts">
        <label>Material<select data-opt="material">${options(c.materials.map((m) => ({ value: m.id, label: m.name })), item.opts.material)}</select></label>
        <label>Strength<select data-opt="strength">${options(c.strengths.map((s) => ({ value: s.id, label: s.name })), item.opts.strength)}</select></label>
        <label>Color<select data-opt="color">${options(c.colors.map((x) => ({ value: x, label: x })), item.opts.color)}</select></label>
        <label>Qty<input data-opt="qty" type="number" min="1" max="99" value="1" inputmode="numeric"></label>
      </div>
      <label class="notes-label"><span>Notes for this part <em>(optional)</em></span>
        <input data-opt="notes" maxlength="500" placeholder="Orientation, finish, which way is up…"></label>
      <div class="line-total"><span class="s-calc"></span><b class="s-total"></b></div>
    </div>`;
  el.addEventListener('input', (e) => {
    const key = e.target.dataset.opt;
    if (!key) return;
    item.opts[key] = key === 'qty' ? clampQty(e.target.value) : e.target.value;
    updateCustomRow(item);
    renderSummary();
  });
  $('.remove', el).addEventListener('click', () => removeCustom(item.id));
  item.el = el;
  $('#custom-list').append(el);
  updateCustomRow(item);
}

function updateCustomRow(item) {
  const el = item.el;
  const meta = $('.fmeta', el);
  const body = $('.upload-body', el);
  el.classList.toggle('has-error', item.status === 'error');
  if (item.status === 'analyzing') {
    meta.innerHTML = '<span class="spinner"></span>Measuring your model…';
    body.hidden = true;
    return;
  }
  if (item.status === 'error') {
    meta.textContent = item.error;
    body.hidden = true;
    return;
  }
  const a = item.analysis;
  const p = priceCustomItem(a, item.opts, state.config);
  meta.textContent = `${(item.file.size / 1024 / 1024).toFixed(1)} MB · ${a.parts} part${a.parts === 1 ? '' : 's'} · ${a.triangles.toLocaleString()} triangles`;
  body.hidden = false;
  $('.s-size-label', el).textContent = a.itemSizesMm.length > 1 ? 'Largest piece' : 'Size';
  $('.s-size', el).textContent = a.sizeMm.map((n) => Math.round(n)).join(' × ') + ' mm';
  $('.s-vol', el).textContent = `${a.volumeCm3.toFixed(1)} cm³`;
  $('.s-grams', el).textContent = `≈ ${p.grams} g`;
  $('.s-each', el).textContent = fmt(p.each);
  const atMin = p.each === roundCents(state.config.minimumPerPart) && p.grams * p.material.pricePerGram < p.each;
  $('.s-calc', el).textContent = atMin
    ? `${p.qty} × ${fmt(p.each)} (minimum per part)`
    : `${p.qty} × ${p.grams} g × ${fmt(p.material.pricePerGram)}/g`;
  $('.s-total', el).textContent = fmt(p.total);

  const warn = $('.warn', el);
  const build = state.config.buildVolumeMm;
  const warnings = [];
  if (!a.itemSizesMm.every((size) => fitsBuildVolume(size, build)))
    warnings.push(`Part of this model is larger than our ${build.join(' × ')} mm print area. We may need to split it or scale it down, and we'll ask you first.`);
  if (Math.max(...a.sizeMm) < 2)
    warnings.push('This model is very small. It may have been exported in the wrong units (for example meters instead of millimeters).');
  warn.hidden = !warnings.length;
  warn.textContent = warnings.join(' ');
}

function removeCustom(id) {
  const i = state.custom.findIndex((x) => x.id === id);
  if (i < 0) return;
  state.custom[i].el.remove();
  state.custom.splice(i, 1);
  renderSummary();
}

// ---------------- Summary ----------------

function orderLines() {
  const lines = [];
  for (const l of state.cart) {
    const p = state.products.find((x) => x.id === l.productId);
    lines.push({ kind: 'cart', key: l.key, name: p.name, meta: l.color, qty: l.qty, total: roundCents(p.price * l.qty) });
  }
  for (const item of state.custom) {
    if (item.status === 'analyzing') {
      lines.push({ kind: 'custom', id: item.id, name: item.file.name, meta: 'Measuring…', qty: item.opts.qty, total: null });
    } else if (item.status === 'ready') {
      const p = priceCustomItem(item.analysis, item.opts, state.config);
      lines.push({
        kind: 'custom', id: item.id, name: item.file.name, qty: p.qty, total: p.total,
        meta: `Custom · ${p.material.name} · ${p.color} · ≈${p.grams} g each`,
      });
    }
  }
  return lines;
}

function renderSummary() {
  const lines = orderLines();
  const list = $('#summary-list');
  const count = state.cart.reduce((s, l) => s + l.qty, 0) + state.custom.filter((x) => x.status !== 'error').reduce((s, x) => s + x.opts.qty, 0);

  list.innerHTML = lines.length
    ? lines
        .map((l) =>
          l.kind === 'cart'
            ? `<li data-key="${esc(l.key)}">
                 <span class="li-name">${esc(l.name)}</span><span class="li-price">${fmt(l.total)}</span>
                 <span class="li-meta">${esc(l.meta)}</span>
                 <span class="li-actions">
                   <span class="qty-mini"><button type="button" data-act="dec" aria-label="Decrease quantity">−</button><span>${l.qty}</span><button type="button" data-act="inc" aria-label="Increase quantity">+</button></span>
                   <button type="button" class="link-btn" data-act="rm">Remove</button>
                 </span>
               </li>`
            : `<li data-custom="${l.id}">
                 <span class="li-name">${esc(l.name)}</span><span class="li-price">${l.total == null ? '…' : fmt(l.total)}</span>
                 <span class="li-meta">${l.qty} × ${esc(l.meta)}</span>
                 <span class="li-actions"><button type="button" class="link-btn" data-act="rm">Remove</button></span>
               </li>`,
        )
        .join('')
    : `<li class="empty">Nothing here yet. Add a product from the <a href="#shop">shop</a> or <a href="#custom">upload a 3MF</a>.</li>`;

  list.onclick = (e) => {
    const btn = e.target.closest('button[data-act]');
    if (!btn) return;
    const li = btn.closest('li');
    if (li.dataset.custom) return removeCustom(Number(li.dataset.custom));
    const line = state.cart.find((l) => l.key === li.dataset.key);
    if (btn.dataset.act === 'inc') line.qty = clampQty(line.qty + 1);
    if (btn.dataset.act === 'dec') line.qty -= 1;
    if (btn.dataset.act === 'rm' || line.qty < 1) state.cart = state.cart.filter((l) => l !== line);
    renderSummary();
  };

  const total = roundCents(lines.reduce((s, l) => s + (l.total || 0), 0));
  $('#summary-total').textContent = fmt(total);

  const badge = $('#cart-count');
  if (badge.textContent !== String(count)) {
    badge.textContent = count;
    badge.classList.remove('bump');
    void badge.offsetWidth;
    badge.classList.add('bump');
  }

  const analyzing = state.custom.some((x) => x.status === 'analyzing');
  const btn = $('#submit-btn');
  if (btn.dataset.busy) return;
  btn.disabled = !lines.length || analyzing;
  btn.textContent = !lines.length ? 'Add something to your order' : analyzing ? 'Measuring your files…' : `Send order · ${fmt(total)}`;
}

// ---------------- Checkout ----------------

function setupForm() {
  const form = $('#order-form');
  const errorBox = $('#form-error');

  form.addEventListener('input', (e) => {
    if (e.target.matches('[aria-invalid="true"]') && e.target.checkValidity()) e.target.removeAttribute('aria-invalid');
  });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    errorBox.hidden = true;

    const invalid = [...form.elements].filter((f) => f.willValidate && !f.checkValidity());
    form.querySelectorAll('[aria-invalid]').forEach((f) => f.removeAttribute('aria-invalid'));
    if (invalid.length) {
      invalid.forEach((f) => f.setAttribute('aria-invalid', 'true'));
      showError(invalid.some((f) => f.type === 'email' && f.value) ? 'Please enter a valid email address.' : 'Please fill in the highlighted fields.');
      invalid[0].focus();
      return;
    }

    const ready = state.custom.filter((x) => x.status === 'ready');
    const fd = new FormData();
    fd.append('customer', JSON.stringify(Object.fromEntries(new FormData(form))));
    fd.append('cart', JSON.stringify(state.cart.map(({ productId, color, qty }) => ({ productId, color, qty }))));
    fd.append('custom', JSON.stringify(ready.map((x) => x.opts)));
    ready.forEach((x) => fd.append('files', x.file, x.file.name));

    const btn = $('#submit-btn');
    btn.dataset.busy = '1';
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner"></span>Sending your order…';
    try {
      const res = await fetch('/api/order', { method: 'POST', body: fd });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || 'Something went wrong. Please try again.');
      showSuccess(data, Object.fromEntries(new FormData(form)));
    } catch (err) {
      showError(err.message === 'Failed to fetch' ? 'We couldn’t reach the server. Check your connection and try again.' : err.message);
    } finally {
      delete btn.dataset.busy;
      renderSummary();
    }
  });

  $('#new-order').addEventListener('click', () => {
    $('#success').hidden = true;
    $('#checkout').hidden = false;
    location.hash = '#shop';
  });

  function showError(msg) {
    errorBox.textContent = msg;
    errorBox.hidden = false;
  }
}

function showSuccess(data, customer) {
  state.cart = [];
  state.custom.forEach((x) => x.el.remove());
  state.custom = [];
  $('#order-form').reset();
  renderSummary();

  $('#checkout').hidden = true;
  const box = $('#success');
  $('#success-title').textContent = `Thanks, ${customer.firstName}! Your order is in.`;
  $('#success-body').innerHTML =
    `Your order number is <b>${esc(data.orderId)}</b> (estimated ${fmt(data.total)}). ` +
    `We'll check your order and email <b>${esc(customer.email)}</b> with the final price and timing before we print anything.`;
  box.hidden = false;
  box.scrollIntoView({ behavior: 'smooth', block: 'center' });
  box.focus({ preventScroll: true });
}

// ---------------- Toast ----------------

let toastTimer;
function toast(msg) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 2200);
}
